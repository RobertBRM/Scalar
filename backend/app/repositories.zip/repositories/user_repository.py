
from psycopg.rows import dict_row
from app.database import get_connection


def create_user(email: str, password_hash: str):
    with get_connection() as conn:
        with conn.cursor(row_factory=dict_row) as cursor:
            cursor.execute(
                """
                INSERT INTO users (email, password_hash)
                VALUES (%s, %s)
                RETURNING id, email, created_at
                """,
                (email, password_hash)
            )
            return cursor.fetchone()


def get_user_by_id(user_id: int):
    with get_connection() as conn:
        with conn.cursor(row_factory=dict_row) as cursor:
            cursor.execute(
                "SELECT id, email, created_at FROM users WHERE id = %s",
                (user_id,)
            )
            return cursor.fetchone()


def get_user_by_email(email: str):
    # Internal use for authentication
    with get_connection() as conn:
        with conn.cursor(row_factory=dict_row) as cursor:
            cursor.execute(
                "SELECT * FROM users WHERE email = %s",
                (email,)
            )
            return cursor.fetchone()


def update_user(user_id: int, email: str | None = None,
                password_hash: str | None = None):
    updates = {}
    if email is not None:
        updates["email"] = email
    if password_hash is not None:
        updates["password_hash"] = password_hash

    if not updates:
        return get_user_by_id(user_id)

    from psycopg import sql

    assignments = sql.SQL(", ").join(
        sql.SQL("{} = %s").format(sql.Identifier(column))
        for column in updates
    )

    query = sql.SQL(
        "UPDATE users SET {} WHERE id = %s "
        "RETURNING id, email, created_at"
    ).format(assignments)

    with get_connection() as conn:
        with conn.cursor(row_factory=dict_row) as cursor:
            cursor.execute(query, (*updates.values(), user_id))
            return cursor.fetchone()


def delete_user(user_id: int):
    with get_connection() as conn:
        with conn.cursor(row_factory=dict_row) as cursor:
            cursor.execute(
                "DELETE FROM users WHERE id = %s RETURNING id",
                (user_id,)
            )
            return cursor.fetchone()

