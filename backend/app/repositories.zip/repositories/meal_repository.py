
from psycopg.rows import dict_row
from psycopg import sql
from app.database import get_connection
from app.models.meal import MealCreate, MealUpdate


def create_meal(meal: MealCreate):
    data = meal.model_dump(exclude_unset=True)

    if data.get("logged_at") is None:
        data.pop("logged_at", None)

    columns = sql.SQL(", ").join(
        sql.Identifier(key) for key in data
    )
    placeholders = sql.SQL(", ").join(
        sql.Placeholder() for _ in data
    )

    query = sql.SQL(
        "INSERT INTO meals ({}) VALUES ({}) RETURNING *"
    ).format(columns, placeholders)

    with get_connection() as conn:
        with conn.cursor(row_factory=dict_row) as cursor:
            cursor.execute(query, tuple(data.values()))
            return cursor.fetchone()


def get_meal_by_id(meal_id: int):
    with get_connection() as conn:
        with conn.cursor(row_factory=dict_row) as cursor:
            cursor.execute(
                "SELECT * FROM meals WHERE id = %s",
                (meal_id,)
            )
            return cursor.fetchone()


def get_meals_by_user(user_id: int):
    with get_connection() as conn:
        with conn.cursor(row_factory=dict_row) as cursor:
            cursor.execute(
                """
                SELECT * FROM meals
                WHERE user_id = %s
                ORDER BY logged_at DESC
                """,
                (user_id,)
            )
            return cursor.fetchall()


def update_meal(meal_id: int, meal: MealUpdate):
    data = meal.model_dump(exclude_unset=True)

    if not data:
        return get_meal_by_id(meal_id)

    assignments = sql.SQL(", ").join(
        sql.SQL("{} = %s").format(sql.Identifier(key))
        for key in data
    )

    query = sql.SQL(
        "UPDATE meals SET {} WHERE id = %s RETURNING *"
    ).format(assignments)

    with get_connection() as conn:
        with conn.cursor(row_factory=dict_row) as cursor:
            cursor.execute(query, (*data.values(), meal_id))
            return cursor.fetchone()


def delete_meal(meal_id: int):
    with get_connection() as conn:
        with conn.cursor(row_factory=dict_row) as cursor:
            cursor.execute(
                "DELETE FROM meals WHERE id = %s RETURNING id",
                (meal_id,)
            )
            return cursor.fetchone()

